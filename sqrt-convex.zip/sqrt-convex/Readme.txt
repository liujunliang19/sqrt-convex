In order to run the code,your computer need to install Maple,Matlab and setup cvx package in Matlab. 

Firstly, run the maple file "sqrt-convex1.mw" and run the code in file "sq1.m" in the Matlab window that pops up.
 
Using commands "rats(y)" you can get the value of parameters and the last eight term is \alpha_i (1-4) and \beta_i(1-4).

Secondly, do the same operation to "sqrt-convex1.mw" and "sq1.m", you can get the value of parameters  \gamma_i (1-63).
(We already put the parameters \alpha_i and \beta_i  in  these two programme).

Any question please contact email 	429581858@qq.com .