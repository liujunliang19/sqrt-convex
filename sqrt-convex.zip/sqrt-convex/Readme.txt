In order to run the code,your computer need to install Maple,Matlab and setup cvx package in Matlab. 

Firstly, run the maple file 'sqrt-convex1.mw' and run the code in file 'sq1.m' in the Matlab window that pops up.
 
Using commands "rats(y)" you can get the value of parameters \alpha_i,\beta_i ,\eta_j(Last eight term is \alpha_i (1-4) and \beta_i(1-4)). The value of them can be found if file 'data2.txt'.

Secondly, do the same operation to "sqrt-convex2.mw" and "sq2.m", you can get the value of parameters  \lambda_j (1-63).
(We already put the parameters \alpha_i and \beta_i  in  these two programme). The value of \lambda_i can be found if file 'data2.txt'.

Any question please contact email  429581858@qq.com .